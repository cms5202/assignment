select * from users

select * from board order by bseq

select * from reply where bseq=1 order by rstep, rlevel, rseq desc