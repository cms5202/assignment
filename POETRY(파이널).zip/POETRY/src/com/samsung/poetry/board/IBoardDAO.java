package com.samsung.poetry.board;

import java.util.ArrayList;

public interface IBoardDAO {

		//게시글 추가
		public void addBoard(BoardVO vo);
		
		//게시글 수정
		public BoardVO updateBoard(BoardVO vo);
		
		public void updateBoardPro(BoardVO vo);

		//게시글 삭제
		public void deleteBoard(BoardVO vo);
		
		//게시글 상세
		public BoardVO getBoard(int bseq);

		//게시글 목록
		public ArrayList<BoardVO> getBoardList(BoardVO vo);
		
		//댓글 달기
		public ArrayList<ReplyVO> addReply(ReplyVO vo);
		
		//꼬리 댓글 달기
		public ArrayList<ReplyVO> addReply2(ReplyVO vo);
		
		//댓글 삭제
		public String deleteReply(ReplyVO vo);
		
		//댓글 목록
		public ArrayList<ReplyVO> getReplyList(int bseq);
		
		// 추천수 
		public int getLike(int bseq);	

		// 비추천수 
		public int getHate(int bseq);
		
		// 추천수 추가
		public String addLike(int bseq);
		
		// 비추천수 추가
		public String addHate(int bseq);
		
		//오늘의 시
		public BoardVO getTodayPoem(String weather);
}
