package com.samsung.poetry.board;

import java.sql.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ReplyVO {
	private int rseq;
	private String rcontent;
	private String ruser;
	private Date rdate;
	private int rlevel;
	private int rstep;
	private int bseq;
	
	List<BoardVO> boardList;
	
	public int getRseq() {
		return rseq;
	}

	public void setRseq(int rseq) {
		this.rseq = rseq;
	}

	public String getRcontent() {
		return rcontent;
	}

	public void setRcontent(String rcontent) {
		this.rcontent = rcontent;
	}

	public String getRuser() {
		return ruser;
	}

	public void setRuser(String ruser) {
		this.ruser = ruser;
	}

	public Date getRdate() {
		return rdate;
	}

	public void setRdate(Date rdate) {
		this.rdate = rdate;
	}

	public int getRlevel() {
		return rlevel;
	}

	public void setRlevel(int rlevel) {
		this.rlevel = rlevel;
	}

	public int getRstep() {
		return rstep;
	}

	public void setRstep(int rstep) {
		this.rstep = rstep;
	}

	public int getBseq() {
		return bseq;
	}

	public void setBseq(int bseq) {
		this.bseq = bseq;
	}

	public List<BoardVO> getBoardList() {
		return boardList;
	}

	public void setBoardList(List<BoardVO> boardList) {
		this.boardList = boardList;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ReplyVO [rseq=");
		builder.append(rseq);
		builder.append(", rcontent=");
		builder.append(rcontent);
		builder.append(", ruser=");
		builder.append(ruser);
		builder.append(", rdate=");
		builder.append(rdate);
		builder.append(", rlevel=");
		builder.append(rlevel);
		builder.append(", rstep=");
		builder.append(rstep);
		builder.append(", bseq=");
		builder.append(bseq);
		builder.append(", boardList=");
		builder.append(boardList);
		builder.append("]");
		return builder.toString();
	}

}
