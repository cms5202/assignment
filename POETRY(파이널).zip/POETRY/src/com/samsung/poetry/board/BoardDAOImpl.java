package com.samsung.poetry.board;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAOImpl implements IBoardDAO {

	@Autowired
	SqlSession session;
	
	// 게시글 추가
	public void addBoard(BoardVO vo) {
		System.out.println("BoardDAOImpl의 addBoard");
		session.insert("board.addBoard", vo);
	}

	// 게시글 수정
	public BoardVO updateBoard(BoardVO vo) {
		System.out.println("BoardDAOImpl의 updateBoard");
		BoardVO board = session.selectOne("board.getBoard", vo);
		return board;
	}
	
	public void updateBoardPro(BoardVO vo){
		session.update("board.updateBoard", vo);
	}

	// 게시글 삭제
	public void deleteBoard(BoardVO vo) {
		System.out.println("BoardDAOImpl의 deleteBoard");
		session.delete("board.deleteBoard", vo);
	}

	// 게시글 상세
	public BoardVO getBoard(int bseq) {
		System.out.println("BoardDAOImpl의 getBoard");
		session.update("board.updateBcnt", bseq);
		BoardVO board = session.selectOne("board.getBoard", bseq);
		return board;
	}

	// 게시글 목록
	public ArrayList<BoardVO> getBoardList(BoardVO vo) {
		System.out.println("BoardDAOImpl의 getBoardList");
		List<BoardVO> boardList = session.selectList("board.getBoardList", vo);
		return (ArrayList) boardList;
	}

	// 댓글 달기
	public ArrayList<ReplyVO> addReply(ReplyVO vo) {
		System.out.println("BoardDAOImpl의 addReply");
		session.insert("board.addReply", vo);
		List<ReplyVO> replyList=session.selectList("board.getReplyList", vo);
		return (ArrayList)replyList;
	}

	// 꼬리 댓글 달기
	public ArrayList<ReplyVO> addReply2(ReplyVO vo) {
		System.out.println("BoardDAOImpl의 addReply2");
		session.update("board.updateReply2", vo);
		session.insert("board.addReply2", vo);
		List<ReplyVO> replyList=session.selectList("board.getReplyList", vo);
		return (ArrayList)replyList;
	}

	// 댓글 삭제
	public String deleteReply(ReplyVO vo) {
		System.out.println("BoardDAOImpl의 deleteReply");
		List<ReplyVO> list=session.selectList("board.checkReplyBeforeDelete", vo);
		System.out.println(list.size());
		System.out.println("확인: "+list);
		if(list.size()==0){
			session.delete("board.deleteReply", vo);
			return "true";
		}else{
			return "false";
		}
	}

	// 댓글 목록
	public ArrayList<ReplyVO> getReplyList(int bseq) {
		System.out.println("BoardDAOImpl의 getReplyList");
		List<ReplyVO> replyList = session
				.selectList("board.getReplyList", bseq);
		return (ArrayList) replyList;
	}

	// 추천수
	public int getLike(int bseq) {
		System.out.println("BoardDAOImpl의 getLike");
		int like = session.selectOne("board.getLike", bseq);
		return like;

	}

	// 비추천수
	public int getHate(int bseq) {
		System.out.println("BoardDAOImpl의 getHate");
		int hate = session.selectOne("board.getHate", bseq);
		return hate;
	}

	// 추천수 추가
	public String addLike(int bseq) {
		System.out.println("BoardDaoImpl의 addLike");
		session.update("board.addLike", bseq);
		return "addLike success";
	}

	// 비추천수 추가
	public String addHate(int bseq) {
		System.out.println("BoardDaoImpl의 addHate");
		session.update("board.addHate", bseq);
		return "addHate success";
	}

	// 오늘의 시
	public BoardVO getTodayPoem(String weather) {
		System.out.println("BoardDaoImpl의 getTodayPoem");
		Map<String, Integer> map=new HashMap<String, Integer>();
		map.put("Clear", 21);
		map.put("Sunny", 21);
		map.put("Rain", 22);
		map.put("Showers", 22);
		map.put("Sleet", 23);
		map.put("Snow", 23);
		map.put("Flurries", 23);
		map.put("Ice", 23);
		map.put("Thunderstorm", 24);
		map.put("Cloud", 25);
		map.put("Fog", 26);
		map.put("Haze", 26);
		map.put("Mist", 26);
		
		int bseq=3;
		for (String key: map.keySet()) {
			if(weather.contains(key)){
				bseq=map.get(key);
			}
		}
		
		BoardVO board = session.selectOne("board.getBoard", bseq);
		return board;
	}
}
