package com.samsung.poetry.board;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class BoardController {

	@Autowired
	IBoardService boardSev;

	// 게시글 추가
	@RequestMapping("/addBoard.do")
	public String addBoard(BoardVO vo) {
		System.out.println("BoardController의 addBoard");
		boardSev.addBoard(vo);
		return "getBoardList.do";
	}

	@RequestMapping("/updateBoard.do")
	public String updateBoard(@RequestParam("bseq") int bseq, HttpSession session, Model m) {
		String id = (String)session.getAttribute("id");

		if(id == null){
			
			return "login.jsp";
		}
		
		BoardVO vo=new BoardVO();
		vo.setBseq(bseq);
		BoardVO board = boardSev.updateBoard(vo);
		m.addAttribute("board", board);
		return "updateBoard.jsp";
	}
	
	@RequestMapping("/updateBoardPro.do")
	public String updateBoardPro(BoardVO vo) {
		boardSev.updateBoardPro(vo);
		return "getBoardList.do";
	
	}

	// 게시글 삭제
	@RequestMapping("/deleteBoard.do")
	public String deleteBoard(BoardVO vo) {
		System.out.println("BoardController의 deleteBoard");
		boardSev.deleteBoard(vo);
		return "getBoardList.do";
	}


	// 게시글 상세
	@RequestMapping("/getBoard.do")
	public String getBoard(Model m, @RequestParam("bseq") int bseq) {
		System.out.println("BoardController의 getBoard");
		BoardVO board=boardSev.getBoard(bseq);
		m.addAttribute("board", board);
		return "boardDetail.jsp";
	}

	// 게시글 목록
	@RequestMapping("/getBoardList.do")
	public String getBoardList(BoardVO vo, Model m, HttpSession session) {
		System.out.println("BoardController의 getBoardList");
		String id = (String)session.getAttribute("id");
		
		if(id == null){
			return "login.jsp";
		}
		
		if(vo.getSearchCondition() == null ){
			vo.setSearchCondition("TITLE");
		}
		
		if(vo.getSearchKeyword() == null ){
			vo.setSearchKeyword("");
		}

		ArrayList<BoardVO> boardList = boardSev.getBoardList(vo);
		m.addAttribute("boardList", boardList);
		return "boardList.jsp";
	}

	// 댓글 달기
	@RequestMapping("/addReply.do")
	@ResponseBody
	public ArrayList<ReplyVO> addReply(Model m, ReplyVO vo, HttpSession hs) {
		System.out.println("BoardController의 addReply");
		vo.setRuser((String)hs.getAttribute("id"));
		System.out.println(vo);
		ArrayList<ReplyVO> replyList=boardSev.addReply(vo);
		return replyList;
	}

	// 꼬리 댓글 달기
	@RequestMapping("/addReply2.do")
	@ResponseBody
	public ArrayList<ReplyVO> addReply2(ReplyVO vo, HttpSession hs) {
		System.out.println("BoardController의 addReply2");
		vo.setRuser((String)hs.getAttribute("id"));
		System.out.println(vo);
		ArrayList<ReplyVO> replyList=boardSev.addReply2(vo);
		return replyList;
	}

	// 댓글 삭제
	@RequestMapping("/deleteReply.do")
	@ResponseBody
	public String deleteReply(ReplyVO vo) {
		System.out.println("BoardController의 deleteReply");
		System.out.println(vo);
		String result=boardSev.deleteReply(vo);
		System.out.println("result: "+result);
		return result;
	}

	// 댓글 목록
	@RequestMapping("/getReplyList.do")
	@ResponseBody
	public ArrayList<ReplyVO> getReplyList(Model m, @RequestParam("bseq") int bseq) {
		System.out.println("BoardController의 getReplyList");
		ArrayList<ReplyVO> replyList=boardSev.getReplyList(bseq);
		return replyList;
	}
	
	// 추천수 
	@RequestMapping("/getLike.do")
	@ResponseBody
	public String getLike(@RequestParam("bseq") int bseq){
		System.out.println("Boardcontroller의 getLike");
		int like=boardSev.getLike(bseq);
		return like+"";
	}
	
	// 비추천수 
	@RequestMapping("/getHate.do")
	@ResponseBody
	public String getHate(@RequestParam("bseq") int bseq){
		System.out.println("Boardcontroller의 getHate");
		int hate=boardSev.getHate(bseq);
		return hate+"";
	}
	
	// 추천수 추가
	@RequestMapping("/addLike.do")
	@ResponseBody
	public String addLike(@RequestParam("bseq") int bseq){
		System.out.println("BoardController의 addLike");
		String result=boardSev.addLike(bseq);
		return result;
	}
	
	// 비추천수 추가
	@RequestMapping("/addHate.do")
	@ResponseBody
	public String addHate(@RequestParam("bseq") int bseq){
		System.out.println("BoardController의 addHate");
		String result=boardSev.addHate(bseq);
		return result;
	}
	
	//오늘의 시
	@RequestMapping("/getTodayPoem.do")
	@ResponseBody
	public BoardVO getTodayPoem(String weather){
		System.out.println("BoardController의 getTodayPoem");
		System.out.println("오늘의 날씨: "+weather);
		BoardVO board=boardSev.getTodayPoem(weather);
		return board;
	}
}
