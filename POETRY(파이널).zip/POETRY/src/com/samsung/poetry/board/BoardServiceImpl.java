package com.samsung.poetry.board;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoardServiceImpl implements IBoardService {

	@Autowired
	IBoardDAO dao;

	// 게시글 추가
	public void addBoard(BoardVO vo) {
		System.out.println("BoardServiceImpl의 addBoard");
		dao.addBoard(vo);
	}

	// 게시글 수정
	public BoardVO updateBoard(BoardVO vo) {
		BoardVO board = dao.updateBoard(vo);
		return board;
	}
	
	public void updateBoardPro(BoardVO vo){
		dao.updateBoardPro(vo);
	}

	// 게시글 삭제
	public void deleteBoard(BoardVO vo) {
		System.out.println("BoardServiceImpl의 deleteBoard");
		dao.deleteBoard(vo);
	}

	// 게시글 상세
	public BoardVO getBoard(int bseq) {
		System.out.println("BoardServiceImpl의 getBoard");
		BoardVO board = dao.getBoard(bseq);
		return board;
	}


	// 게시글 목록
	public ArrayList<BoardVO> getBoardList(BoardVO vo) {
		System.out.println("BoardServiceImpl의 getBoardList");
		ArrayList<BoardVO> boardList = dao.getBoardList(vo);
		return boardList;
	}

	// 댓글 달기
	public ArrayList<ReplyVO> addReply(ReplyVO vo) {
		System.out.println("BoardServiceImpl의 addReply");
		ArrayList<ReplyVO> replyList=dao.addReply(vo);
		return replyList;
	}

	// 꼬리 댓글 달기
	public ArrayList<ReplyVO> addReply2(ReplyVO vo) {
		System.out.println("BoardServiceImpl의 addReply2");
		ArrayList<ReplyVO> replyList=dao.addReply2(vo);
		return replyList;
	}

	// 댓글 삭제
	public String deleteReply(ReplyVO vo) {
		System.out.println("BoardServiceImpl의 deleteReply");
		String result=dao.deleteReply(vo);
		return result;
	}

	// 댓글 목록
	public ArrayList<ReplyVO> getReplyList(int bseq) {
		System.out.println("BoardServiceImpl의 getReplyList");
		ArrayList<ReplyVO> replyList=dao.getReplyList(bseq);
		return replyList;
	}

	// 추천수
	public int getLike(int bseq){
		System.out.println("BoardServiceImpl의 getLike");
		int like=dao.getLike(bseq);
		return like;
	}

	// 비추천수
	public int getHate(int bseq){
		System.out.println("BoardServiceImpl의 getHate");
		int hate=dao.getHate(bseq);
		return hate;
	}
	
	//추천수 추가
	public String addLike(int bseq){
		System.out.println("BoardServiceImpl의 addLike");
		String result=dao.addLike(bseq);
		return result;
	}
	
	// 비추천수 추가
	public String addHate(int bseq){
		System.out.println("BoardServiceImpl의 addHate");
		String result=dao.addHate(bseq);
		return result;
	}
	
	//오늘의 시
	public BoardVO getTodayPoem(String weather){
		System.out.println("BoardServiceImpl의 getTodayPoem");
		BoardVO board=dao.getTodayPoem(weather);
		return board;
	}
}
