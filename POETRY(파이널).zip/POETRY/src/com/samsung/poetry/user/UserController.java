package com.samsung.poetry.user;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UserController {

	@Autowired
	IUserService userSev;
	
	// 로그인
	@RequestMapping(method=RequestMethod.POST, value="/login.do")
	public String login(HttpSession session, UserVO vo){
		System.out.println("UserController의 login");
		System.out.println("vo: "+vo);
		UserVO user = userSev.login(vo);
		System.out.println("user: "+user);
		if(user!=null){
			session.setAttribute("id", user.getId());
			return "getBoardList.do";
		}else{
			return "redirect:login.jsp";
		}
	}

	// 로그아웃
	@RequestMapping("/logout.do")
	public String logout(HttpSession session){
		System.out.println("UserController의 logout");
		session.invalidate();
		return "redirect:login.jsp";
	}

	// 회원가입
	@RequestMapping("/signup.do")
	public String signup(Model m, UserVO vo, @RequestParam("password1") String password1, @RequestParam("password2") String password2){
		System.out.println("UserController의 signup");
		System.out.println("vo: "+vo);
		System.out.println("password1: "+password1);
		System.out.println("password2: "+password2);
		
		// 비밀번호 확인이 불일치시
				if(!password1.equals(password2)) {
					vo.setPassword(password1);
					String msg = " 불일치";
					m.addAttribute("msg", msg);
					m.addAttribute("id", vo.getId());
					m.addAttribute("nickname", vo.getNickname());
					m.addAttribute("name", vo.getName());
					m.addAttribute("email", vo.getEmail());
					m.addAttribute("birth", vo.getBirth());
					m.addAttribute("intro", vo.getIntro());
					System.out.println("비밀번호 확인 if 문 내부");
					
					return "signup.jsp";
				}else{
					vo.setPassword(password1);
					System.out.println("비밀번호 확인 else 문 내부");
					
					userSev.signup(vo);
				
					return "redirect:login.jsp";
				} 
	}
	
	// 회원정보 보기
	@RequestMapping("/getUserInfo.do")
	public String getUserInfo(Model m, @RequestParam("buser") String buser){
		System.out.println("BoardController의 getUserInfo");
		UserVO user=userSev.getUserInfo(buser);
		m.addAttribute("user", user);
		return "userInfo.jsp";
	}
}
