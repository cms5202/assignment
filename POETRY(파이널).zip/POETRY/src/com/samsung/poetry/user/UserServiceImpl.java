package com.samsung.poetry.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements IUserService{

	@Autowired
	IUserDAO dao;

	// 로그인
	public UserVO login(UserVO vo) {
		System.out.println("UserServiceImpl의 login");
		UserVO user=dao.login(vo);
		return user;
	}

	// 회원가입
	public void signup(UserVO vo) {
		System.out.println("UserServiceImpl의 signup");
		dao.signup(vo);
	}
	
	// 회원정보 보기
	public UserVO getUserInfo(String buser){
		System.out.println("UserServiceImpl의 getUserInfo");
		UserVO user=dao.getUserInfo(buser);
		return user;
	}
}
