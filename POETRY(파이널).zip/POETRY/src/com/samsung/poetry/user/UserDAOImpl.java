package com.samsung.poetry.user;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserDAOImpl implements IUserDAO {

	@Autowired
	SqlSession session;
	
	// 로그인
	public UserVO login(UserVO vo) {
		System.out.println("UserDAOImpl의 login");
		UserVO user=session.selectOne("user.getUser", vo);
		return user;
	}

	// 회원가입
	public void signup(UserVO vo) {
		System.out.println("UserDAOImpl의 signup");
		session.insert("user.insertUser", vo);
	}

	// 회원정보 보기
	public UserVO getUserInfo(String buser) {
		System.out.println("UserDaoImpl의 getUserInfo");
		UserVO user = session.selectOne("user.getUserInfo", buser);
		return user;
	}
}
