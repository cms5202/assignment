package com.samsung.poetry.user;

public interface IUserService {

	//로그인
	public UserVO login(UserVO vo);
	
	//회원가입
	public void signup(UserVO vo);
	
	// 회원정보 보기
	public UserVO getUserInfo(String buser);
	
}
